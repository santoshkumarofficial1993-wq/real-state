# Northpoint Properties — Real Estate Website

A complete, static (HTML/CSS/JS) residential real-estate marketing site built to be
fast, accessible, distinctive, and aligned with **Google Ads landing-page and
publisher policies**. No build step, no framework — open the files in any browser
or drop them on any static host.

---

## ⚠️ Read first: replace the placeholder business details

The site ships with **placeholder** brand/contact data. Google Ads requires
**accurate, verifiable** business information, so you **must** swap these before
advertising (and ideally before going live):

| Placeholder | Replace with |
|---|---|
| `Northpoint Properties` (name, logo wordmark) | Your real business name |
| `(512) 555-0199` (`tel:+15125550199`) | Your real phone |
| `hello@northpointproperties.example` | Your real email |
| `1400 North Loop Blvd, Suite 210, Austin, TX 78701` | Your real office address |
| `License #0000000` | Your real brokerage license number |
| `northpointproperties.example` (canonical, OG, sitemap, robots) | Your real domain |
| Listings, prices, agents, testimonials, stats | Real listings & real, consented reviews |
| Social links (`href="#"`) | Your real profile URLs |

> **Legal pages are templates, not legal advice.** Privacy, Terms, Cookies,
> Disclaimer, Accessibility, and Fair Housing are solid starting points written for
> a US/TX residential brokerage. Have them reviewed by a qualified attorney and
> tailored to your jurisdiction and actual data practices before relying on them.

Search-and-replace tip (from the project root):
- Find `northpointproperties.example` and `(512) 555-0199` / `+15125550199` across all `.html`.

---

## Pages

**Core**
- `index.html` — Home (hero + property search, featured listings, why-us, process, testimonials, CTA)
- `listings.html` — Property listings grid with filter bar
- `services.html` — Buying, selling, valuations, FAQ
- `about.html` — Story, values, team, stats
- `contact.html` — Contact form (client-side validated) + office info + map

**Legal / compliance** (linked in every footer)
- `privacy.html` · `terms.html` · `cookies.html` · `disclaimer.html` · `accessibility.html` · `fair-housing.html`

**Other**
- `404.html` — Friendly not-found page
- `robots.txt`, `sitemap.xml`, `site.webmanifest`

## Assets
- `assets/css/styles.css` — Design system (OKLCH tokens, components, responsive, motion)
- `assets/js/main.js` — Mobile drawer, cookie consent, form validation, scroll reveals
- `assets/favicon.svg` — Compass "north point" logomark · `assets/icon-mask.svg` — Safari pinned-tab icon

## Project context (impeccable skill)
- `PRODUCT.md` — Strategy: register, users, brand personality, principles
- `DESIGN.md` — Visual system: palette, type, layout, components

---

## How to view locally

It's static HTML — but because pages reference shared assets, run a tiny local
server so paths and the cookie banner behave exactly as in production:

```bash
# Python 3
python -m http.server 8123
# then open http://localhost:8123

# or Node
npx serve .
```

You can also double-click `index.html` to open via `file://` (most things work;
a local server is recommended).

## Deploy
Upload the whole folder to any static host (Netlify, Vercel, GitHub Pages, Cloudflare
Pages, S3, or traditional shared hosting). **Serve over HTTPS** — Google Ads expects
a secure, working destination. Set a real domain and update the canonical/OG/sitemap URLs.

---

## Google Ads policy — how this site is set up to comply

> This is a best-effort checklist, not a guarantee of approval. Final compliance
> depends on your real content, business, and how you run your ads.

**Site quality & transparency**
- [x] Clear value proposition and what the business does, above the fold
- [x] Honest, original content — no "click-bait" or misleading claims
- [x] Real, working navigation; every nav/footer link resolves (no dead ends)
- [x] Custom `404.html` so broken links don't trap users
- [x] Easy-to-find contact info (phone, email, address) on every page + dedicated Contact page
- [x] About page establishing who is behind the business
- [x] No automatic downloads, no disruptive interstitials, no surprise redirects

**Required/expected legal & disclosure pages**
- [x] **Privacy Policy** — describes data collected, use, sharing, cookies, retention, and user rights (required when collecting data / running ads)
- [x] **Cookie Policy** + a working **consent banner** (accept/decline, choice stored, re-openable)
- [x] **Terms of Service**
- [x] **Disclaimer** (listing accuracy, valuations are not appraisals, not professional advice)
- [x] **Accessibility Statement**
- [x] **Fair Housing / Equal Housing Opportunity** notice (important for US real estate ads) + EHO statement in every footer

**Technical / experience signals**
- [x] Mobile-responsive (tested at 390 px and desktop)
- [x] Fast: no heavy frameworks; images lazy-loaded; fonts preconnected
- [x] Accessible: semantic landmarks, labelled forms, visible focus, AA contrast, `prefers-reduced-motion` honored
- [x] SEO basics: per-page titles/descriptions, canonical, Open Graph, JSON-LD, `sitemap.xml`, `robots.txt`

**Still on you before running ads**
- [ ] Replace all placeholder business data (see table above)
- [ ] Serve over HTTPS on your real domain
- [ ] Have legal pages reviewed by an attorney; make sure the Privacy Policy matches what you *actually* collect (e.g. if you add Google Analytics / Ads conversion tracking, keep the cookie/privacy text accurate)
- [ ] Only use real testimonials/listings you have the rights and consent to publish
- [ ] If you collect leads, make sure the form actually delivers (see below)

---

## Wiring up the contact form
The form currently validates on the client and shows a success message — it does
**not** send anywhere yet. To receive leads, point it at a backend or form service
(Formspree, Netlify Forms, Basin, your own endpoint). In `contact.html`, set the
`<form>`'s `action`/`method` (or integrate the service's script) and adjust the
submit handler in `assets/js/main.js` as needed.

## Design system notes
- **Palette:** deep pine-green identity on pure white + a restrained brass accent
  (deliberately avoids the navy-and-gold and green-on-cream real-estate clichés).
- **Type:** Libre Caslon Display (headings) + Hanken Grotesk (body), via Google Fonts.
- **Colour is OKLCH**; tokens live at the top of `styles.css` — change `--primary`,
  `--accent`, etc. in one place to re-skin the whole site.

## Image credits
Photography is loaded from [Unsplash](https://unsplash.com) (free to use under the
Unsplash License). For production, consider self-hosting optimized copies of the
photos you license/own, and use real photos of your actual listings and team.
