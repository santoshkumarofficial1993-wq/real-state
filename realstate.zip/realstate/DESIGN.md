# Design

## Theme

Classic-trust residential brokerage. An established local firm rendered as a
physical object: a letterpress business card and a brass nameplate on a brick
storefront. Deep pine-green identity on **pure white** (deliberately NOT cream —
green-on-cream is the AI default we reject), warmed by a single restrained brass
accent. Mood: steady, local, candid. Photography of real homes carries the
emotion; the chrome stays quiet so the houses and the numbers do the talking.

Light theme only. Physical scene: a buyer on a phone, daytime, comparing agencies
in a browser tab — needs to read fast and feel safe. That forces high-contrast,
bright, document-clean surfaces, not a moody dark UI.

## Color

OKLCH throughout. Strategy: **Committed-leaning-Restrained** — pine green owns the
header, footer, hero scrim, and CTAs (identity); white owns the working surfaces;
brass appears only as a thin accent (rules, active states, small marks).

| Token | OKLCH | Role |
|---|---|---|
| `--bg` | `oklch(1 0 0)` | Page background — pure white, no hidden warmth |
| `--surface` | `oklch(0.978 0.004 160)` | Cards/sections, faintest green tint (NOT cream) |
| `--surface-2` | `oklch(0.955 0.006 160)` | Insets, hovered rows |
| `--ink` | `oklch(0.23 0.018 160)` | Body text — ~13:1 on white |
| `--ink-soft`| `oklch(0.36 0.016 160)` | Secondary headings |
| `--muted` | `oklch(0.46 0.014 160)` | Captions/labels — ≥4.5:1 on white |
| `--line` | `oklch(0.9 0.008 160)` | Hairline borders |
| `--primary` | `oklch(0.40 0.087 160)` | Brand pine green (palette seed) |
| `--primary-deep`| `oklch(0.30 0.062 162)` | Header/footer/CTA-band ground |
| `--primary-press`| `oklch(0.34 0.078 160)` | Button active |
| `--accent` | `oklch(0.70 0.108 72)` | Brass — rules, active nav, small marks |
| `--accent-deep`| `oklch(0.56 0.10 65)` | Brass text on light, accent borders |

Text-on-fill: white text on green fills (primary buttons, CTA band). Brass is used
as line/mark, not as a text-bearing fill; where brass labels sit on light, use
`--accent-deep` for contrast. Body ≥4.5:1 verified.

## Typography

Contrast-axis pairing (heritage serif + clean grotesque), both off the
reflex-reject list.

- **Display / headings:** `"Libre Caslon Display", Georgia, serif` — Caslon is the
  classic institutional book/legal face; carries "established" without costume.
- **Body / UI / numerals:** `"Hanken Grotesk", system-ui, sans-serif` — neutral,
  legible, modern; handles prices, bed/bath stats, forms, nav.
- Prices and key stats set in Hanken with tabular numerals for alignment.

Scale: fluid `clamp()`, ratio ~1.25. Display max ≤ 4.5rem. Headings
`text-wrap: balance`; long prose `text-wrap: pretty`. Letter-spacing on display
≥ -0.02em. Body line-length capped 68ch.

## Layout

- Container 1200px (1340px for hero/full-bleed bands), fluid gutters via `clamp()`.
- Header: sticky, white, hairline bottom border, compass mark + Caslon wordmark,
  inline nav, phone link + green CTA. Mobile: hamburger → full-screen `<dialog>` drawer.
- Hero: full-bleed property photo, pine-green left-weighted gradient scrim, white
  Caslon headline, and a real **property search bar** (location / type / price) as
  the primary affordance.
- Listings: real cards (the correct affordance here) on
  `repeat(auto-fit, minmax(300px, 1fr))` — photo, status pill, price, address,
  bed/bath/sqft row.
- Alternating image+text bands for "why us" (not identical icon-cards).
- Process: a genuine 3-step sequence (numbered legitimately).
- Footer: pine-deep ground, 4 columns, full legal/disclosure link set, Equal Housing
  Opportunity statement + mark.

## Components

Buttons (primary green / outline / ghost), input + select fields, property card,
status pill, stat band, testimonial quote, accordion (FAQ), cookie-consent banner,
toast, breadcrumb, legal-page prose container, section header.

## Motion

Restrained. One coordinated hero settle on load (scrim + headline + search rise,
exponential ease-out). Listing/section reveals are subtle and stagger only within a
list, enhancing already-visible content. Hover: card lift + image scale (transform
only). Full `prefers-reduced-motion` fallbacks (instant, no transform).

## Iconography & Marks

Compass "north point" needle as the logomark (pine roundel, brass north tip) —
ties to the name and to "finding home / direction." Inline SVG line icons for
bed/bath/area and feature lists, 1.5px stroke. Equal Housing Opportunity mark in footer.
