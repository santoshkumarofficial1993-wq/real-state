/* Northpoint Properties — interactions
   Progressive enhancement: site is fully usable with JS disabled. */
(function () {
  "use strict";
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---- Mobile drawer (native <dialog>) -------------------------------- */
  var toggle = document.querySelector("[data-nav-toggle]");
  var drawer = document.getElementById("nav-drawer");
  if (toggle && drawer) {
    toggle.addEventListener("click", function () {
      if (typeof drawer.showModal === "function") drawer.showModal();
      else drawer.setAttribute("open", "");
    });
    drawer.addEventListener("click", function (e) {
      if (e.target.matches("[data-drawer-close]") || e.target.closest("[data-drawer-close]")) drawer.close();
      // click on backdrop (the dialog element itself)
      if (e.target === drawer) drawer.close();
    });
  }

  /* ---- Footer year ----------------------------------------------------- */
  var yearEls = document.querySelectorAll("[data-year]");
  yearEls.forEach(function (el) { el.textContent = new Date().getFullYear(); });

  /* ---- Reveal on scroll (enhances already-visible content) ------------- */
  var revealEls = document.querySelectorAll(".reveal, .reveal-stagger");
  function revealAll() { revealEls.forEach(function (el) { el.classList.add("in"); }); }
  if (revealEls.length) {
    if (reduceMotion || !("IntersectionObserver" in window)) {
      revealAll();
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) { entry.target.classList.add("in"); io.unobserve(entry.target); }
        });
      }, { rootMargin: "0px 0px -8% 0px", threshold: 0.08 });
      revealEls.forEach(function (el) { io.observe(el); });
      // Safety net: never let content stay hidden (headless/hidden-tab renders).
      window.setTimeout(revealAll, 1600);
    }
  }

  /* ---- Hero load choreography ----------------------------------------- */
  var heroInner = document.querySelector(".hero-inner");
  if (heroInner) {
    if (reduceMotion) heroInner.classList.add("ready");
    else window.requestAnimationFrame(function () {
      window.requestAnimationFrame(function () { heroInner.classList.add("ready"); });
    });
  }

  /* ---- Favorite toggle (visual only) ----------------------------------- */
  document.addEventListener("click", function (e) {
    var fav = e.target.closest(".fav");
    if (!fav) return;
    e.preventDefault();
    var on = fav.getAttribute("aria-pressed") === "true";
    fav.setAttribute("aria-pressed", on ? "false" : "true");
    fav.querySelector("svg").style.fill = on ? "none" : "currentColor";
  });

  /* ---- Toast ----------------------------------------------------------- */
  function toast(msg) {
    var t = document.getElementById("toast");
    if (!t) return;
    t.querySelector("[data-toast-msg]").textContent = msg;
    t.classList.add("show");
    window.clearTimeout(toast._t);
    toast._t = window.setTimeout(function () { t.classList.remove("show"); }, 4000);
  }

  /* ---- Contact form (client-side validation, no backend) --------------- */
  var form = document.querySelector("[data-contact-form]");
  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var valid = true;
      form.querySelectorAll("[required]").forEach(function (input) {
        var field = input.closest(".field");
        var ok;
        if (input.type === "checkbox") ok = input.checked;
        else ok = input.value.trim() !== "" && (input.type !== "email" || /.+@.+\..+/.test(input.value));
        if (field) field.classList.toggle("invalid", !ok);
        else { input.setAttribute("aria-invalid", String(!ok)); input.style.outline = ok ? "" : "2px solid var(--accent-deep)"; input.style.outlineOffset = "3px"; }
        if (!ok) valid = false;
      });
      if (!valid) { toast("Please check the highlighted fields."); return; }
      form.style.display = "none";
      var ok = document.querySelector("[data-form-success]");
      if (ok) { ok.style.display = "block"; ok.setAttribute("tabindex", "-1"); ok.focus(); }
      toast("Thanks — your enquiry has been received.");
    });
    form.querySelectorAll("[required]").forEach(function (input) {
      var evt = input.type === "checkbox" ? "change" : "input";
      input.addEventListener(evt, function () {
        var field = input.closest(".field");
        var filled = input.type === "checkbox" ? input.checked : input.value.trim() !== "";
        if (field) { if (field.classList.contains("invalid") && filled) field.classList.remove("invalid"); }
        else if (filled) { input.style.outline = ""; input.removeAttribute("aria-invalid"); }
      });
    });
  }

  /* ---- Cookie consent banner ------------------------------------------ */
  var KEY = "np-cookie-consent";
  var banner = document.getElementById("cookie");
  if (banner) {
    var stored = null;
    try { stored = window.localStorage.getItem(KEY); } catch (_) {}
    if (!stored) {
      window.setTimeout(function () { banner.classList.add("show"); }, 900);
    }
    banner.addEventListener("click", function (e) {
      var choice = e.target.getAttribute("data-consent");
      if (!choice) return;
      try { window.localStorage.setItem(KEY, choice); } catch (_) {}
      banner.classList.remove("show");
    });
  }
  // Allow re-opening preferences from footer / cookie policy page
  document.querySelectorAll("[data-cookie-settings]").forEach(function (el) {
    el.addEventListener("click", function (e) {
      e.preventDefault();
      if (banner) banner.classList.add("show");
    });
  });
})();
