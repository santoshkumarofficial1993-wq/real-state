# Product

## Register

brand

## Users

Prospective home buyers and sellers in a single metro market — primarily households
researching a move (first-time buyers, growing families, downsizers). They arrive
from search and paid ads, often on mobile, in a high-consideration, high-anxiety
purchase. Their context: comparing agencies, trying to gauge whether this firm is
established, local, and trustworthy before handing over their largest transaction.
The job to be done: "Help me find the right home (or the right buyer) with someone
I can trust, and make the first step — reaching out — feel safe and easy."

## Product Purpose

Northpoint Properties is a residential real-estate brokerage marketing site. It
exists to convert search/ad traffic into qualified leads (buyer/seller enquiries,
valuation requests, listing views) while passing Google Ads landing-page and
publisher-policy review. Success = a credible, transparent, fast, fully-navigable
site with genuine value (real listings, real guidance), complete legal/disclosure
pages, and a low-friction path to contact. It is NOT a transactional portal; it
communicates trust and routes interest to human agents.

## Brand Personality

Established, grounded, reassuring. Voice is plain-spoken and confident, never
hype-y or salesy — the tone of a firm that has done this for decades and has
nothing to prove. Three words: **steady, local, candid.** Emotional goal: lower
the visitor's risk-perception. Make a big scary decision feel handled by competent
people. Warmth comes from clarity and directness, not exclamation marks.

## Anti-references

- Navy-and-gold "luxury broker" cliché (Sotheby's knock-offs); gold serif on dark blue.
- Forest-green-on-cream wellness/organic look — the saturated AI default.
- Zillow/portal density: firehose of filters, ad-stuffed, impersonal.
- Crypto/startup hype: gradient text, neon, "revolutionary," countdown urgency.
- Generic AI landing scaffold: identical icon-cards, an uppercase tracked eyebrow
  over every section, hero-metric template, stocky CTA gradients.

## Design Principles

1. **Trust is earned with specifics.** Real addresses, real numbers, named people,
   honest disclosures. Concrete detail beats adjectives ("steady" is shown, not said).
2. **Show the homes.** This is an image-led category; photography carries the mood.
   Never a colored block where a property photo belongs.
3. **One obvious next step per screen.** Every fold routes to contact / search /
   a listing. No dead ends — required for ads, good for humans.
4. **Disclosure as a feature, not fine print.** Privacy, fair-housing, and terms are
   built and linked prominently; transparency is part of the trust pitch.
5. **Structure over decoration.** "Classic" is delivered through hierarchy, rules,
   and typographic restraint — not ornament.

## Accessibility & Inclusion

Target WCAG 2.1 AA. Body text ≥4.5:1 contrast; large text ≥3:1; visible focus rings;
keyboard-operable nav, menu, and cookie banner. Honor `prefers-reduced-motion`
(reveals/parallax degrade to instant). Semantic landmarks and headings, descriptive
alt text on every property/portrait image, labelled form fields with error text.
Equal-housing / fair-housing commitment stated and linked sitewide.
